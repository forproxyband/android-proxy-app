module proxy-agent-sdk

go 1.26

require github.com/gorilla/websocket v1.5.1

require golang.org/x/net v0.52.0 // indirect
