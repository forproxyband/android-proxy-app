package main

/*
#include <stdlib.h>
*/
import "C"

import (
	"proxy-agent-sdk/pkg/agent"
)

//export StartAgent
func StartAgent() {
	agent.StartAgent()
}

//export StopAgent
func StopAgent() {
	agent.StopAgent()
}

func main() {}

