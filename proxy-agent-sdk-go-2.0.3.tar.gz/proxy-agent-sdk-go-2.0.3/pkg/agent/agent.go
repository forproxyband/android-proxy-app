package agent

import (
	"context"
	"proxy-agent-sdk/internal/config"
	slog "proxy-agent-sdk/internal/log"
	"proxy-agent-sdk/internal/supervisor"
	"sync"
)

var (
	sup     *supervisor.Supervisor
	cancel  context.CancelFunc
	mu      sync.Mutex
	running bool
)

// StartAgent initializes and starts the agent.
func StartAgent() {
	mu.Lock()
	defer mu.Unlock()

	if running {
		return
	}

	logger := slog.New()
	cfg := config.FromEnvAndFlags()

	var ctx context.Context
	ctx, cancel = context.WithCancel(context.Background())

	sup = supervisor.New(logger)
	go func() {
		if err := sup.Start(ctx, cfg); err != nil {
			logger.Error("supervisor exited with error", "error", err)
		}
	}()

	running = true
}

// StopAgent gracefully stops the agent.
func StopAgent() {
	mu.Lock()
	defer mu.Unlock()

	if !running {
		return
	}

	if cancel != nil {
		cancel()
	}

	running = false
}
