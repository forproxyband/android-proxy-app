# Proxy Agent SDK (Integration Guide)

This archive contains the Proxy Agent SDK built as standalone binaries and C-shared libraries.

## Structure

- `bin/`: Standalone executables for various platforms.
- `lib/`: C-shared libraries (`.so`, `.dll`).
- `include/`: C header files (`.h`) required for integration.

## Using the C Library

The library exports two main functions:

1. `void StartAgent()`: Initializes and starts the agent in the background. It reads configuration from environment variables or default values.
2. `void StopAgent()`: Gracefully stops the running agent.

### Example (C)

```c
#include "libproxy-agent.h"
#include <stdio.h>
#include <unistd.h>

int main() {
    printf("Starting Proxy Agent...\n");
    StartAgent();
    
    // Let it run for 10 seconds
    sleep(10);
    
    printf("Stopping Proxy Agent...\n");
    StopAgent();
    
    return 0;
}
```

### Configuration

The agent uses the following environment variables:
- `balancer_host`: Hostname of the balancer.
- `balancer_port`: Port of the balancer.
- `agent_key`: Authentication key.
- `enable_netagent`: `true`/`false` to enable network agent features.

## Supported Platforms

- **Linux**: amd64, arm64 (glibc compatible)
- **Windows**: amd64 (.dll)
