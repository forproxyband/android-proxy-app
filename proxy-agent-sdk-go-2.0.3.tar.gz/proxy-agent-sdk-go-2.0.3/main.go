package main

import (
	"context"
	"os"
	"os/signal"
	"syscall"
	"time"

	"proxy-agent-sdk/internal/config"
	slog "proxy-agent-sdk/internal/log"
	"proxy-agent-sdk/internal/supervisor"
)

func main() {
	// Root context with cancellation on OS signals
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	// Parse configuration (flags > env > defaults)
	cfg := config.FromEnvAndFlags()

	// Initialize logger
	logger := slog.New()
	logger.Info("agent starting...")
	logger.Info("config",
		"balancer_host", cfg.BalancerHost,
		"balancer_port", cfg.BalancerPort,
		"fallback_file_url", cfg.FallbackFileURL,
		"key", mask(cfg.Key),
		"source_ip_list", cfg.SourceIPList,
		"enable_netagent", cfg.EnableNetAgent,
		"sender_tls", cfg.SenderTLS,
		"sender_timeout_ms", cfg.SenderTimeoutMS,
		"enable_systeminfo", cfg.EnableSystemInfo,
		"enable_heartbeat", cfg.EnableHeartbeat,
		"heartbeat_interval_sec", cfg.HeartbeatIntervalSec,
	)

	// Start supervisor skeleton
	sup := supervisor.New(logger)
	if err := sup.Start(ctx, cfg); err != nil {
		logger.Error("supervisor exited with error", "error", err)
		os.Exit(1)
	}

	// Give logs a moment to flush (stdout)
	time.Sleep(50 * time.Millisecond)
}

func mask(s string) string {
	if s == "" {
		return "none"
	}
	if len(s) <= 4 {
		return "****"
	}
	return s[:2] + "****" + s[len(s)-2:]
}
