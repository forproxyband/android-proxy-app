package log

import (
	"fmt"
	"log"
	"os"
	"sync"
	"time"
)

// Logger is a minimal structured logger wrapper.
type Logger struct {
	l     *log.Logger
	mu    sync.Mutex
	level Level
}

type Level int

const (
	DebugLevel Level = iota
	InfoLevel  Level = iota
	WarnLevel
	ErrorLevel
)

func New() *Logger {
	return &Logger{l: log.New(os.Stdout, "", 0), level: InfoLevel}
}

func (lg *Logger) log(level, msg string, kv ...any) {
	lg.mu.Lock()
	defer lg.mu.Unlock()
	ts := time.Now().Format(time.RFC3339)
	line := fmt.Sprintf("%s level=%s msg=\"%s\"", ts, level, msg)
	if len(kv) > 0 {
		// Ensure even number of kv
		if len(kv)%2 != 0 {
			kv = append(kv, "<missing>")
		}
		for i := 0; i < len(kv); i += 2 {
			line += fmt.Sprintf(" %v=%v", kv[i], kv[i+1])
		}
	}
	lg.l.Println(line)
}

func (lg *Logger) Info(msg string, kv ...any)  { lg.log("INFO", msg, kv...) }
func (lg *Logger) Warn(msg string, kv ...any)  { lg.log("WARN", msg, kv...) }
func (lg *Logger) Error(msg string, kv ...any) { lg.log("ERROR", msg, kv...) }
func (lg *Logger) Debug(msg string, kv ...any) { lg.log("DEBUG", msg, kv...) }
