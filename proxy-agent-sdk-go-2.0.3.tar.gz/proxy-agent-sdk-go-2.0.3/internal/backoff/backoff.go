package backoff

import (
    "math"
    "math/rand"
    "time"
)

// Strategy defines a generic backoff policy.
type Strategy interface {
    NextDelay() time.Duration
    Reset()
}

// ExponentialJitter implements an exponential backoff with optional full jitter.
// Inspired by Java's ExponentialJitterBackoff used in the existing agent.
type ExponentialJitter struct {
    // Configuration
    BaseDelay time.Duration // initial backoff delay
    MaxDelay  time.Duration // maximum cap for delay
    Factor    float64       // exponential factor, typically 2.0
    Jitter    float64       // 0..1 fraction for randomization (full jitter = 1.0)

    // state
    attempt int
    rnd     *rand.Rand
}

// NewExponentialJitter returns a configured exponential backoff with jitter.
func NewExponentialJitter(base, max time.Duration, factor, jitter float64) *ExponentialJitter {
    if base <= 0 {
        base = 100 * time.Millisecond
    }
    if max <= 0 {
        max = 10 * time.Second
    }
    if factor < 1 {
        factor = 2
    }
    if jitter < 0 {
        jitter = 0
    }
    if jitter > 1 {
        jitter = 1
    }
    return &ExponentialJitter{
        BaseDelay: base,
        MaxDelay:  max,
        Factor:    factor,
        Jitter:    jitter,
        rnd:       rand.New(rand.NewSource(time.Now().UnixNano())),
    }
}

func (e *ExponentialJitter) NextDelay() time.Duration {
    // Backoff = min(Base * Factor^attempt, Max)
    pow := math.Pow(e.Factor, float64(e.attempt))
    raw := float64(e.BaseDelay) * pow
    if raw > float64(e.MaxDelay) {
        raw = float64(e.MaxDelay)
    }
    d := time.Duration(raw)

    if e.Jitter > 0 {
        // Full jitter: pick random in [0, d]
        maxJ := int64(float64(d) * e.Jitter)
        if maxJ > 0 {
            j := time.Duration(e.rnd.Int63n(maxJ + 1))
            d = d - time.Duration(maxJ) + j // distribute within [d-maxJ, d]
            if d < 0 {
                d = j // fallback to [0,maxJ]
            }
        }
    }

    e.attempt++
    return d
}

func (e *ExponentialJitter) Reset() { e.attempt = 0 }

// SleepCtx sleeps for the specified duration or until the context is done.
// Returns true if completed the sleep, false if cancelled.
func SleepCtx(ctxDone <-chan struct{}, d time.Duration) bool {
    timer := time.NewTimer(d)
    defer timer.Stop()
    select {
    case <-ctxDone:
        return false
    case <-timer.C:
        return true
    }
}
