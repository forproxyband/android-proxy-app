package netagent

import (
	"context"
	"crypto/tls"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"

	slog "proxy-agent-sdk/internal/log"
	"proxy-agent-sdk/internal/systeminfo"

	"github.com/gorilla/websocket"
)

// WSUplink is a minimal WebSocket client that connects to a registrator and
// keeps the connection alive until context is canceled or an error occurs.
type WSUplink struct {
	log *slog.Logger

	conn       *websocket.Conn
	writeMu    sync.Mutex
	tunnels    sync.Map // map[uint64]net.Conn
	infoSentAt time.Time
}

func NewWSUplink(l *slog.Logger) *WSUplink { return &WSUplink{log: l} }

func (w *WSUplink) writeJSON(v interface{}) error {
	w.writeMu.Lock()
	defer w.writeMu.Unlock()
	return w.conn.WriteJSON(v)
}

func (w *WSUplink) writeBinary(data []byte) error {
	w.writeMu.Lock()
	defer w.writeMu.Unlock()
	return w.conn.WriteMessage(websocket.BinaryMessage, data)
}

// Start connects to ws(s)://host:port+path with Authorization header (apiKey).
// It blocks until the context is canceled or a connection/read error occurs.
func (w *WSUplink) Start(ctx context.Context, useTLS bool, host string, port int, path string, apiKey string, httpTimeout time.Duration, info systeminfo.SystemInfo) error {
	scheme := "ws"
	if useTLS {
		scheme = "wss"
	}
	if path == "" {
		path = "/"
	}
	u := url.URL{Scheme: scheme, Host: fmt.Sprintf("%s:%d", host, port), Path: path}

	d := websocket.Dialer{
		Proxy:             http.ProxyFromEnvironment,
		HandshakeTimeout:  httpTimeout,
		EnableCompression: true,
	}
	if scheme == "wss" {
		d.TLSClientConfig = &tls.Config{InsecureSkipVerify: true} // to mirror Java trustAll/verifyHost=false
	}

	apiKey = strings.TrimSpace(apiKey)
	hdr := http.Header{}
	if apiKey != "" {
		hdr.Set("Authorization", "Bearer "+apiKey)
		w.log.Info("ws header set", "auth", "Bearer [REDACTED]")
	} else {
		w.log.Warn("ws missing apiKey; Authorization header NOT set")
	}
	hdr.Set("User-Agent", "Proxy-Agent-SDK-Go/1.0")

	w.log.Info("ws dialing", "url", u.String(), "headers", fmt.Sprintf("%v", hdr))
	conn, resp, err := d.DialContext(ctx, u.String(), hdr)
	if err != nil {
		if resp != nil {
			w.log.Warn("ws dial failed", "url", u.String(), "error", err, "status", resp.Status, "statusCode", resp.StatusCode)
		} else {
			w.log.Warn("ws dial failed", "url", u.String(), "error", err)
		}
		return err
	}
	w.conn = conn
	defer func() {
		_ = conn.Close()
		w.tunnels.Range(func(key, value interface{}) bool {
			if c, ok := value.(net.Conn); ok {
				_ = c.Close()
			}
			return true
		})
	}()
	w.log.Info("ws connected", "url", u.String())

	// Send INFO command immediately after connection
	infoMsg := AgentInfoMessage{
		Command:      string(ActionInfo),
		UUID:         apiKey, // Use apiKey as UUID (mirrors Java behavior where apiKey often serves as identifier)
		Host:         info.Hostname,
		SourceIPList: info.IPs,
	}
	if err := w.writeJSON(infoMsg); err != nil {
		w.log.Warn("ws info send failed", "error", err)
		return err
	}
	w.infoSentAt = time.Now()
	w.log.Info("ws info sent", "uuid", infoMsg.UUID)

	// Reader loop to keep connection alive and react to server frames
	conn.SetReadLimit(10 << 20) // 10MB similar to max message size
	_ = conn.SetReadDeadline(time.Time{})

	for {
		select {
		case <-ctx.Done():
			w.log.Info("ws context cancelled; closing")
			return nil
		default:
			msgType, data, rerr := conn.ReadMessage()
			if rerr != nil {
				w.log.Warn("ws read error", "error", rerr)
				return rerr
			}

			switch msgType {
			case websocket.TextMessage:
				w.handleTextMessage(ctx, data)
			case websocket.BinaryMessage:
				w.handleBinaryMessage(data)
			case websocket.CloseMessage:
				w.log.Info("ws close frame received")
				return nil
			}
		}
	}
}

func (w *WSUplink) handleTextMessage(ctx context.Context, data []byte) {
	var msg AgentControlMessage
	if err := json.Unmarshal(data, &msg); err != nil {
		w.log.Warn("failed to decode text message", "error", err, "data", string(data))
		return
	}

	cmd := strings.ToUpper(msg.Command)
	switch CommandActionAgent(cmd) {
	case ActionOpen:
		if msg.ConnectionID == nil {
			w.log.Warn("OPEN command without connectionId")
			return
		}
		go w.handleOpen(ctx, *msg.ConnectionID, msg.Host, msg.Port)
	case ActionClose:
		if msg.ConnectionID == nil {
			w.log.Warn("CLOSE command without connectionId")
			return
		}
		if cAny, ok := w.tunnels.LoadAndDelete(*msg.ConnectionID); ok {
			if c, ok := cAny.(net.Conn); ok {
				w.log.Info("closing tunnel per server request", "connID", *msg.ConnectionID)
				_ = c.Close()
			}
		}
	default:
		w.log.Debug("unknown text command", "command", cmd)
	}
}

func (w *WSUplink) handleOpen(ctx context.Context, connID uint64, host string, port int) {
	w.log.Info("opening tunnel", "connID", connID, "target", net.JoinHostPort(host, strconv.Itoa(port)))

	dialer := net.Dialer{Timeout: 30 * time.Second}
	target, err := dialer.DialContext(ctx, "tcp", net.JoinHostPort(host, strconv.Itoa(port)))
	if err != nil {
		w.log.Warn("failed to dial target", "connID", connID, "error", err)
		_ = w.writeJSON(AgentControlMessage{
			Command:      string(ActionError),
			ConnectionID: &connID,
		})
		return
	}

	w.tunnels.Store(connID, target)
	_ = w.writeJSON(AgentControlMessage{
		Command:      string(ActionOpened),
		ConnectionID: &connID,
	})

	w.log.Info("tunnel opened", "connID", connID)

	go func() {
		defer func() {
			w.tunnels.Delete(connID)
			_ = target.Close()
			_ = w.writeJSON(AgentControlMessage{
				Command:      string(ActionClosed),
				ConnectionID: &connID,
			})
			w.log.Info("tunnel closed", "connID", connID)
		}()

		buf := make([]byte, 32*1024)
		for {
			n, err := target.Read(buf)
			if n > 0 {
				payload := make([]byte, 8+n)
				binary.BigEndian.PutUint64(payload[:8], connID)
				copy(payload[8:], buf[:n])
				if err := w.writeBinary(payload); err != nil {
					w.log.Warn("failed to send binary data to ws", "connID", connID, "error", err)
					return
				}
			}
			if err != nil {
				return
			}
		}
	}()
}

func (w *WSUplink) handleBinaryMessage(data []byte) {
	if len(data) < 8 {
		return
	}
	connID := binary.BigEndian.Uint64(data[:8])
	payload := data[8:]

	if cAny, ok := w.tunnels.Load(connID); ok {
		if c, ok := cAny.(net.Conn); ok {
			_, _ = c.Write(payload)
		}
	}
}
