package netagent

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"sync"
	"sync/atomic"
	"time"

	slog "proxy-agent-sdk/internal/log"
)

// NetAgent describes the sender component lifecycle.
// Phase 3: interface and TCP-based implementation with basic I/O loops.
type NetAgent interface {
	Start(ctx context.Context) error
	Stop()
	Send(b []byte) error
}

// TCPOptions carries connection options for the TCPAgent.
type TCPOptions struct {
	Host         string
	Port         int
	UseTLS       bool // reserved for future
	DialTimeout  time.Duration
	ReadTimeout  time.Duration
	WriteTimeout time.Duration
	OutputIP     string // optional local bind
	SendQueue    int    // capacity for outbound messages
}

// TCPAgent implements a simple TCP client with read/write loops and clean shutdown.
type TCPAgent struct {
	log *slog.Logger
	opt TCPOptions

	conn net.Conn
	cmu  sync.Mutex

	sendQ chan []byte

	closed   atomic.Bool
	stopOnce sync.Once
}

func NewTCPAgent(l *slog.Logger, opt TCPOptions) *TCPAgent {
	if opt.SendQueue <= 0 {
		opt.SendQueue = 1024
	}
	if opt.DialTimeout <= 0 {
		opt.DialTimeout = 10 * time.Second
	}
	return &TCPAgent{log: l, opt: opt, sendQ: make(chan []byte, opt.SendQueue)}
}

// Start establishes TCP connection and runs read/write loops until context is cancelled or error occurs.
func (a *TCPAgent) Start(ctx context.Context) error {
	a.log.Info("netagent start",
		"host", a.opt.Host,
		"port", a.opt.Port,
		"tls", a.opt.UseTLS,
		"timeout", a.opt.DialTimeout.String(),
	)

	var d net.Dialer
	d.Timeout = a.opt.DialTimeout
	d.KeepAlive = 30 * time.Second

	if a.opt.OutputIP != "" {
		if ip, err := netip.ParseAddr(a.opt.OutputIP); err == nil {
			d.LocalAddr = &net.TCPAddr{IP: ip.AsSlice()}
		} else {
			a.log.Warn("invalid OutputIP; skipping bind", "ip", a.opt.OutputIP, "err", err)
		}
	}

	endpoint := fmt.Sprintf("%s:%d", a.opt.Host, a.opt.Port)
	conn, err := d.DialContext(ctx, "tcp", endpoint)
	if err != nil {
		return err
	}

	if tcp, ok := conn.(*net.TCPConn); ok {
		_ = tcp.SetNoDelay(true)
		_ = tcp.SetKeepAlive(true)
		_ = tcp.SetKeepAlivePeriod(30 * time.Second)
	}

	a.cmu.Lock()
	a.conn = conn
	a.cmu.Unlock()

	a.log.Info("netagent connected", "endpoint", endpoint)

	// Start loops
	done := make(chan struct{})
	go func() { a.readLoop(); close(done) }()
	go a.writeLoop()

	// Wait until context done or read loop ends
	select {
	case <-ctx.Done():
		a.log.Info("netagent context cancelled; stopping")
		a.Stop()
	case <-done:
		a.log.Info("netagent read loop finished; stopping")
		a.Stop()
	}
	return nil
}

// Stop closes connection and send queue; idempotent.
func (a *TCPAgent) Stop() {
	a.stopOnce.Do(func() {
		a.closed.Store(true)
		// Close sendQ to stop writer
		close(a.sendQ)
		// Close connection
		a.cmu.Lock()
		if a.conn != nil {
			_ = a.conn.Close()
		}
		a.conn = nil
		a.cmu.Unlock()
	})
}

// Send enqueues data for writing. Returns error if agent is closed or queue is full.
func (a *TCPAgent) Send(b []byte) error {
	if a.closed.Load() {
		return errors.New("agent-closed")
	}
	// copy buffer to avoid caller mutation
	cp := make([]byte, len(b))
	copy(cp, b)
	select {
	case a.sendQ <- cp:
		return nil
	default:
		return errors.New("send-queue-full")
	}
}

func (a *TCPAgent) readLoop() {
	buf := make([]byte, 64*1024)
	for !a.closed.Load() {
		if a.opt.ReadTimeout > 0 {
			_ = a.conn.SetReadDeadline(time.Now().Add(a.opt.ReadTimeout))
		}
		n, err := a.conn.Read(buf)
		if n > 0 {
			a.log.Debug("tcp read", "bytes", n)
			// TODO: forward to uplink when implemented
		}
		if err != nil {
			a.log.Info("tcp read ended", "err", err)
			return
		}
	}
}

func (a *TCPAgent) writeLoop() {
	for chunk := range a.sendQ {
		if a.closed.Load() {
			return
		}
		if a.opt.WriteTimeout > 0 {
			_ = a.conn.SetWriteDeadline(time.Now().Add(a.opt.WriteTimeout))
		}
		_, err := a.conn.Write(chunk)
		if err != nil {
			a.log.Info("tcp write ended", "err", err)
			// trigger stop; read loop will exit when conn closed
			a.Stop()
			return
		}
	}
}
