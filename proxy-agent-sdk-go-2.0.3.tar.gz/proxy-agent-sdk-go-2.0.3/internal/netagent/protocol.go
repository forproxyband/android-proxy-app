package netagent

// CommandActionAgent mirrors CommandActionAgent.java
type CommandActionAgent string

const (
	ActionInfo   CommandActionAgent = "INFO"
	ActionOpened CommandActionAgent = "OPENED"
	ActionClosed CommandActionAgent = "CLOSED"
	ActionError  CommandActionAgent = "ERROR"
	ActionOpen   CommandActionAgent = "OPEN"
	ActionClose  CommandActionAgent = "CLOSE"
)

// CommandFieldAgent mirrors CommandFieldAgent.java
type CommandFieldAgent string

const (
	FieldCommand      CommandFieldAgent = "COMMAND"
	FieldConnectionID CommandFieldAgent = "CONNECTION_ID"
	FieldUUID         CommandFieldAgent = "UUID"
	FieldHost         CommandFieldAgent = "HOST"
	FieldPort         CommandFieldAgent = "PORT"
	FieldSourceIPList CommandFieldAgent = "SOURCE_IP_LIST"
	FieldType         CommandFieldAgent = "TYPE"
	FieldMessage      CommandFieldAgent = "MESSAGE"
)

// AgentInfoMessage is the JSON structure for the INFO command
type AgentInfoMessage struct {
	Command      string   `json:"COMMAND"`
	UUID         string   `json:"UUID"`
	Host         string   `json:"HOST"`
	SourceIPList []string `json:"SOURCE_IP_LIST"`
}

// AgentControlMessage is the JSON structure for OPEN/CLOSE/OPENED/CLOSED/ERROR commands
type AgentControlMessage struct {
	Command      string  `json:"COMMAND"`
	ConnectionID *uint64 `json:"CONNECTION_ID,omitempty"`
	Host         string  `json:"HOST,omitempty"`
	Port         int     `json:"PORT,omitempty"`
	UUID         string  `json:"uuid,omitempty"`
}
