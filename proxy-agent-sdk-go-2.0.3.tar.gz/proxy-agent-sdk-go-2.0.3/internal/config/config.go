package config

import (
	"flag"
	"os"
	"strconv"
)

// Config mirrors important runtime settings from the Java agent.
type Config struct {
	BalancerHost    string
	BalancerPort    int
	FallbackFileURL string
	Key             string
	SourceIPList    string
	// HTTP/WS specifics
	BalancerPath  string // e.g., /getRegistrator
	WSPath        string // e.g., /
	HTTPTimeoutMS int
	// Phase 3 (Net agent) feature flags and options
	EnableNetAgent       bool
	SenderTLS            bool
	SenderTimeoutMS      int
	SenderReadTimeoutMS  int
	SenderWriteTimeoutMS int
	OutputIP             string
	SendQueue            int
	// Phase 4 (System info and heartbeat)
	EnableSystemInfo     bool
	EnableHeartbeat      bool
	HeartbeatIntervalSec int
}

// Defaults aligned with likely Java defaults; adjust later if exact values differ.
const (
	defaultHost = "localhost"
	defaultPort = 1005
)

// FromEnvAndFlags parses configuration with precedence: flags > env > defaults.
func FromEnvAndFlags() Config {
	// Seed from env or defaults
	host := getenv("balancer_host", defaultHost)
	port := getenvInt("balancer_port", defaultPort)
	fallback := getenv("fallback_file_url", "")
	key := getenv("agent_key", "")
	if key == "" {
		key = getenv("AGENT_KEY", "")
	}
	if key == "" {
		key = getenv("key", "")
	}
	if key == "" {
		key = getenv("KEY", "")
	}
	srcIPs := getenv("SOURCE_IP_LIST", "")
	balancerPath := getenv("balancer_path", "/getRegistrator")
	wsPath := getenv("ws_path", "/")
	httpTimeout := getenvInt("http_timeout_ms", 5000)
	enableNet := getenvBool("enable_netagent", true)
	senderTLS := getenvBool("sender_tls", false)
	senderTimeout := getenvInt("sender_timeout_ms", 5000)
	senderReadTimeout := getenvInt("sender_read_timeout_ms", 0)
	senderWriteTimeout := getenvInt("sender_write_timeout_ms", 0)
	outputIP := getenv("output_ip", "")
	sendQueue := getenvInt("send_queue", 1024)
	enableSys := getenvBool("enable_systeminfo", true)
	enableHB := getenvBool("enable_heartbeat", true)
	hbInterval := getenvInt("heartbeat_interval_sec", 60)

	// Define flags with current seed values
	flagHost := flag.String("balancer_host", host, "Balancer host")
	flagPort := flag.Int("balancer_port", port, "Balancer port")
	flagFallback := flag.String("fallback_file_url", fallback, "Fallback file URL")
	flagKey := flag.String("key", key, "Authentication key")
	flagAgentKey := flag.String("agent_key", "", "Authentication key (alternative to -key)")
	flagSrcIPs := flag.String("source_ip_list", srcIPs, "Comma-separated source IP list")
	flagBalancerPath := flag.String("balancer_path", balancerPath, "Balancer HTTP path to obtain registrator (e.g., /getRegistrator)")
	flagWSPath := flag.String("ws_path", wsPath, "WebSocket path on registrator (e.g., /)")
	flagHTTPTimeout := flag.Int("http_timeout_ms", httpTimeout, "HTTP client timeout in milliseconds")
	flagEnableNet := flag.Bool("enable_netagent", enableNet, "Enable Phase 3 net agent connect loop")
	flagSenderTLS := flag.Bool("sender_tls", senderTLS, "Use TLS for sender connection")
	flagSenderTimeout := flag.Int("sender_timeout_ms", senderTimeout, "Dial timeout for sender in milliseconds")
	flagSenderReadTimeout := flag.Int("sender_read_timeout_ms", senderReadTimeout, "Read timeout for sender in milliseconds (0=disabled)")
	flagSenderWriteTimeout := flag.Int("sender_write_timeout_ms", senderWriteTimeout, "Write timeout for sender in milliseconds (0=disabled)")
	flagOutputIP := flag.String("output_ip", outputIP, "Optional local IP to bind outgoing TCP socket")
	flagSendQueue := flag.Int("send_queue", sendQueue, "Outbound send queue capacity for TCP agent")
	flagEnableSystemInfo := flag.Bool("enable_systeminfo", enableSys, "Enable system info collection (Phase 4)")
	flagEnableHeartbeat := flag.Bool("enable_heartbeat", enableHB, "Enable heartbeat ticker (Phase 4)")
	flagHBInterval := flag.Int("heartbeat_interval_sec", hbInterval, "Heartbeat interval in seconds (Phase 4)")

	// Parse flags only once; ignore errors (default behavior prints to stderr on unknown)
	// Consumers embedding this package should call FromEnvAndFlags only from main.
	if !flag.Parsed() {
		flag.Parse()
	}

	finalKey := *flagKey
	if *flagAgentKey != "" {
		finalKey = *flagAgentKey
	}

	return Config{
		BalancerHost:         *flagHost,
		BalancerPort:         *flagPort,
		FallbackFileURL:      *flagFallback,
		Key:                  finalKey,
		SourceIPList:         *flagSrcIPs,
		BalancerPath:         *flagBalancerPath,
		WSPath:               *flagWSPath,
		HTTPTimeoutMS:        *flagHTTPTimeout,
		EnableNetAgent:       *flagEnableNet,
		SenderTLS:            *flagSenderTLS,
		SenderTimeoutMS:      *flagSenderTimeout,
		SenderReadTimeoutMS:  *flagSenderReadTimeout,
		SenderWriteTimeoutMS: *flagSenderWriteTimeout,
		OutputIP:             *flagOutputIP,
		SendQueue:            *flagSendQueue,
		EnableSystemInfo:     *flagEnableSystemInfo,
		EnableHeartbeat:      *flagEnableHeartbeat,
		HeartbeatIntervalSec: *flagHBInterval,
	}
}

func getenv(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

func getenvInt(key string, def int) int {
	if v := os.Getenv(key); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			return n
		}
	}
	return def
}

func getenvBool(key string, def bool) bool {
	if v := os.Getenv(key); v != "" {
		switch v {
		case "1", "true", "TRUE", "True", "yes", "YES", "on", "ON":
			return true
		case "0", "false", "FALSE", "False", "no", "NO", "off", "OFF":
			return false
		}
	}
	return def
}
