package constants

// Placeholder constants mapped from Java.
// These will be filled in future phases to match Java values where applicable.

// NetConstants equivalent
const (
    DefaultConnectTimeoutMillis = 10_000 // example placeholder
    DefaultReadTimeoutMillis    = 30_000 // example placeholder
)

// WSAgentAndServerSpecific equivalent placeholders
const (
    ProtocolVersion = "1.0"
)
