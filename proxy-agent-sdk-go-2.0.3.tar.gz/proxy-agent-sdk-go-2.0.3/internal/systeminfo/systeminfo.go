package systeminfo

import (
    "context"
    "net"
    "os"
    "runtime"
)

// SystemInfo represents a snapshot of basic host information.
type SystemInfo struct {
    OS       string   // runtime.GOOS
    Arch     string   // runtime.GOARCH
    CPUCount int      // runtime.NumCPU()
    Hostname string   // os.Hostname()
    IPs      []string // enumerated from net.Interfaces
}

// Collector defines system info collection behavior.
type Collector interface {
    Collect(ctx context.Context) (SystemInfo, error)
}

// StdCollector implements Collector using only the Go standard library.
type StdCollector struct{}

func NewStdCollector() *StdCollector { return &StdCollector{} }

// Collect gathers basic system information.
func (c *StdCollector) Collect(ctx context.Context) (SystemInfo, error) {
    info := SystemInfo{
        OS:       runtime.GOOS,
        Arch:     runtime.GOARCH,
        CPUCount: runtime.NumCPU(),
    }

    if hn, err := os.Hostname(); err == nil {
        info.Hostname = hn
    }

    info.IPs = listIPs()
    return info, nil
}

// listIPs enumerates interface addresses. Context currently unused but kept for future timeouts.
func listIPs() []string {
    addrs := []string{}
    ifaces, err := net.Interfaces()
    if err != nil {
        return addrs
    }
    for _, iface := range ifaces {
        if (iface.Flags & net.FlagUp) == 0 {
            continue
        }
        ia, err := iface.Addrs()
        if err != nil {
            continue
        }
        for _, a := range ia {
            switch v := a.(type) {
            case *net.IPNet:
                ip := v.IP
                if ip == nil || ip.IsLoopback() {
                    continue
                }
                addrs = append(addrs, ip.String())
            case *net.IPAddr:
                ip := v.IP
                if ip == nil || ip.IsLoopback() {
                    continue
                }
                addrs = append(addrs, ip.String())
            }
        }
    }
    return addrs
}
