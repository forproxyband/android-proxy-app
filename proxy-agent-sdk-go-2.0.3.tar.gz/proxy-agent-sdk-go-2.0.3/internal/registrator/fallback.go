package registrator

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"sync"
	"time"

	slog "proxy-agent-sdk/internal/log"
)

// RegistratorStatisticsInfo mirrors Java fields used to compare registrators.
type RegistratorStatisticsInfo struct {
	Ready       bool           `json:"ready"`
	AgentCount  int            `json:"agentCount"`
	FreeSockets int            `json:"freeSockets"`
	CPULoad     float64        `json:"cpuLoad"`
	RAMLoad     float64        `json:"ramLoad"`
	Network     map[string]any `json:"network"`
}

// DefaultComparator: prefer ready, more free sockets, lower CPU/RAM, lower agentCount.
func DefaultComparator(a, b RegistratorStatisticsInfo) int {
	if a.Ready && !b.Ready {
		return 1
	}
	if !a.Ready && b.Ready {
		return -1
	}
	if a.FreeSockets != b.FreeSockets {
		return a.FreeSockets - b.FreeSockets
	}
	if a.CPULoad != b.CPULoad {
		if a.CPULoad < b.CPULoad {
			return 1
		} else {
			return -1
		}
	}
	if a.RAMLoad != b.RAMLoad {
		if a.RAMLoad < b.RAMLoad {
			return 1
		} else {
			return -1
		}
	}
	if a.AgentCount != b.AgentCount {
		return b.AgentCount - a.AgentCount
	}
	return 0
}

type FallbackSelector struct {
	log        *slog.Logger
	httpClient *http.Client

	mu       sync.RWMutex
	list     []HttpConnectCredentials
	selected *HttpConnectCredentials
}

func NewFallbackSelector(l *slog.Logger, timeout time.Duration) *FallbackSelector {
	return &FallbackSelector{
		log:        l,
		httpClient: &http.Client{Timeout: timeout},
	}
}

func (s *FallbackSelector) LoadList(ctx context.Context, url string, apiKey string) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	if apiKey != "" {
		req.Header.Set("Authorization", "Bearer "+apiKey)
	}
	resp, err := s.httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		b, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("fallback list status=%d body=%s", resp.StatusCode, string(b))
	}
	var arr []map[string]any
	if err := json.NewDecoder(resp.Body).Decode(&arr); err != nil {
		return err
	}
	tmp := make([]HttpConnectCredentials, 0, len(arr))
	for _, m := range arr {
		host, _ := m["host"].(string)
		port, _ := m["port"].(float64)
		hcpF, _ := m["health_check_port"].(float64)
		hcp := int(hcpF)
		if hcp == 0 {
			hcp = 1003
		}
		tmp = append(tmp, HttpConnectCredentials{Host: host, Port: int(port), HealthCheckPort: hcp, APIKey: apiKey})
	}
	s.mu.Lock()
	s.list = tmp
	s.mu.Unlock()
	s.log.Info("loaded fallback registrators", "count", len(tmp))
	return nil
}

func (s *FallbackSelector) ProbeAll(ctx context.Context) error {
	s.mu.RLock()
	lst := append([]HttpConnectCredentials(nil), s.list...)
	s.mu.RUnlock()
	if len(lst) == 0 {
		return errors.New("no fallback registrators")
	}

	bestIdx := -1
	var bestInfo RegistratorStatisticsInfo
	for i, r := range lst {
		info, err := s.probeOne(ctx, r, 1*time.Second)
		if err != nil {
			continue
		}
		if bestIdx < 0 || DefaultComparator(info, bestInfo) > 0 {
			bestIdx, bestInfo = i, info
		}
	}
	if bestIdx < 0 {
		return errors.New("no registrator passed probe")
	}
	s.mu.Lock()
	sel := lst[bestIdx]
	s.selected = &sel
	s.mu.Unlock()
	s.log.Info("selected fallback registrator", "host", sel.Host, "port", sel.Port)
	return nil
}

func (s *FallbackSelector) Selected() (HttpConnectCredentials, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	if s.selected == nil {
		return HttpConnectCredentials{}, false
	}
	return *s.selected, true
}

func (s *FallbackSelector) probeOne(ctx context.Context, r HttpConnectCredentials, timeout time.Duration) (RegistratorStatisticsInfo, error) {
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	url := fmt.Sprintf("http://%s:%d/health", r.Host, r.HealthCheckPort)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return RegistratorStatisticsInfo{}, err
	}
	if r.APIKey != "" {
		req.Header.Set("Authorization", "Bearer "+r.APIKey)
	}
	resp, err := s.httpClient.Do(req)
	if err != nil {
		return RegistratorStatisticsInfo{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode == 401 {
		return RegistratorStatisticsInfo{}, fmt.Errorf("unauthorized")
	}
	var info RegistratorStatisticsInfo
	if err := json.NewDecoder(resp.Body).Decode(&info); err != nil {
		return RegistratorStatisticsInfo{}, err
	}
	return info, nil
}
