package registrator

import (
	"context"
	"errors"

	"proxy-agent-sdk/internal/config"
)

// Address represents where to connect for the registrator/balancer.
type Address struct {
	Host string
	Port int
}

var ErrNoBalancer = errors.New("no balancer host configured")

// Resolver provides selection logic for a registrator/balancer endpoint.
// Phase 2: minimal implementation using config only. Future phases can add
// reading fallback_file_url and dynamic strategies.
type Resolver interface {
	Resolve(ctx context.Context, cfg config.Config) (Address, error)
}

// StaticResolver implements Resolver by using values from Config.
type StaticResolver struct{}

func NewStaticResolver() *StaticResolver { return &StaticResolver{} }

func (r *StaticResolver) Resolve(_ context.Context, cfg config.Config) (Address, error) {
	if cfg.BalancerHost == "" {
		return Address{}, ErrNoBalancer
	}
	return Address{Host: cfg.BalancerHost, Port: cfg.BalancerPort}, nil
}
