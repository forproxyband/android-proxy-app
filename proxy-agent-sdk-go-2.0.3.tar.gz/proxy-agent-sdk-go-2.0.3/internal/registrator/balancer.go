package registrator

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	slog "proxy-agent-sdk/internal/log"
)

// HttpConnectCredentials mirrors Java HttpConnectCredentials.
type HttpConnectCredentials struct {
	Host            string
	Port            int
	HealthCheckPort int
	APIKey          string
}

// BalancerClient queries balancer for registrator selection.
type BalancerClient struct {
	log        *slog.Logger
	httpClient *http.Client
	// Path like "/getRegistrator"
	Path string
}

func NewBalancerClient(l *slog.Logger, timeout time.Duration, path string) *BalancerClient {
	if path == "" {
		path = "/getRegistrator"
	}
	return &BalancerClient{
		log:        l,
		httpClient: &http.Client{Timeout: timeout},
		Path:       path,
	}
}

// Select asks the balancer for registrator credentials.
func (c *BalancerClient) Select(ctx context.Context, balancerHost string, balancerPort int, apiKey string) (HttpConnectCredentials, error) {
	url := fmt.Sprintf("http://%s:%d%s", balancerHost, balancerPort, c.Path)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return HttpConnectCredentials{}, err
	}
	if apiKey != "" {
		req.Header.Set("Authorization", "Bearer "+apiKey)
		c.log.Debug("balancer request with auth", "url", url)
	} else {
		c.log.Warn("balancer request WITHOUT auth", "url", url)
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return HttpConnectCredentials{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return HttpConnectCredentials{}, fmt.Errorf("balancer returned status %d", resp.StatusCode)
	}

	var body struct {
		Host            string `json:"host"`
		Port            int    `json:"port"`
		HealthCheckPort int    `json:"health_check_port"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return HttpConnectCredentials{}, err
	}
	if body.Port == 0 {
		body.Port = 443
	}
	if body.HealthCheckPort == 0 {
		body.HealthCheckPort = 1001
	}
	creds := HttpConnectCredentials{
		Host:            body.Host,
		Port:            body.Port,
		HealthCheckPort: body.HealthCheckPort,
		APIKey:          apiKey,
	}
	return creds, nil
}
