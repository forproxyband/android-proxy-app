package supervisor

import (
	"context"
	"errors"
	"time"

	"proxy-agent-sdk/internal/backoff"
	"proxy-agent-sdk/internal/config"
	slog "proxy-agent-sdk/internal/log"
	"proxy-agent-sdk/internal/netagent"
	"proxy-agent-sdk/internal/registrator"
	"proxy-agent-sdk/internal/systeminfo"
)

// Supervisor coordinates agent components. Phase 1: heartbeat skeleton only.
type Supervisor struct {
	log *slog.Logger
}

func New(l *slog.Logger) *Supervisor { return &Supervisor{log: l} }

// Start runs the main supervision loop until context is cancelled.
func (s *Supervisor) Start(ctx context.Context, cfg config.Config) error {
	s.log.Info("supervisor start")
	defer s.log.Info("supervisor stop")

	// Phase 4: optional heartbeat ticker
	var hb *time.Ticker
	if cfg.EnableHeartbeat {
		interval := time.Duration(cfg.HeartbeatIntervalSec) * time.Second
		if interval <= 0 {
			interval = 60 * time.Second
		}
		hb = time.NewTicker(interval)
		defer hb.Stop()
		s.log.Info("heartbeat feature enabled", "interval", interval.String())
	} else {
		s.log.Info("heartbeat feature disabled")
	}

	// Phase 4: optional system info collector
	var sysCollector systeminfo.Collector
	if cfg.EnableSystemInfo {
		sysCollector = systeminfo.NewStdCollector()
		s.log.Info("systeminfo feature enabled")
	} else {
		s.log.Info("systeminfo feature disabled")
	}

	// Backoff + selection helpers
	bo := backoff.NewExponentialJitter(250*time.Millisecond, 10*time.Second, 2.0, 1.0)

	errCh := make(chan error, 1)

	// Phase 3: optional netagent wiring behind feature flag
	if cfg.EnableNetAgent {
		s.log.Info("netagent feature enabled")
		go func() {
			httpTimeout := time.Duration(cfg.HTTPTimeoutMS) * time.Millisecond
			bal := registrator.NewBalancerClient(s.log, httpTimeout, cfg.BalancerPath)
			fb := registrator.NewFallbackSelector(s.log, httpTimeout)
			fbLoaded := false
			for {
				// Step 1: Try balancer to get registrator
				var creds registrator.HttpConnectCredentials
				var err error
				if cfg.BalancerHost != "" && cfg.BalancerPort != 0 {
					creds, err = bal.Select(ctx, cfg.BalancerHost, cfg.BalancerPort, cfg.Key)
					if err == nil {
						s.log.Info("selected registrator via balancer", "host", creds.Host, "port", creds.Port)
						if creds.Host == "0.0.0.0" {
							s.log.Info("registrator host is 0.0.0.0; replacing with balancer host", "old", creds.Host, "new", cfg.BalancerHost)
							creds.Host = cfg.BalancerHost
						}
					} else {
						s.log.Warn("balancer selection failed", "error", err)
					}
				}

				// Step 2: If balancer failed, attempt fallback list
				if (creds.Host == "" || creds.Port == 0) && cfg.FallbackFileURL != "" {
					if !fbLoaded {
						_ = fb.LoadList(ctx, cfg.FallbackFileURL, cfg.Key)
						fbLoaded = true
					}
					_ = fb.ProbeAll(ctx)
					if c, ok := fb.Selected(); ok {
						creds = c
						s.log.Info("selected registrator via fallback", "host", creds.Host, "port", creds.Port)
					}
				}

				if creds.Host == "" || creds.Port == 0 {
					d := bo.NextDelay()
					s.log.Warn("no registrator available; backing off", "sleep", d)
					if !backoff.SleepCtx(ctx.Done(), d) {
						return
					}
					continue
				}

				// Step 3: Connect WS uplink to registrator
				uplink := netagent.NewWSUplink(s.log)
				cctx, cancel := context.WithCancel(ctx)
				done := make(chan error, 1)

				// Collect fresh system info for the registrator
				var info systeminfo.SystemInfo
				if sysCollector != nil {
					info, _ = sysCollector.Collect(cctx)
				}

				go func() {
					s.log.Debug("starting ws uplink", "host", creds.Host, "port", creds.Port, "hasKey", creds.APIKey != "")
					done <- uplink.Start(cctx, cfg.SenderTLS, creds.Host, creds.Port, cfg.WSPath, creds.APIKey, httpTimeout, info)
				}()

				select {
				case <-ctx.Done():
					cancel()
					return
				case err := <-done:
					cancel()
					if err != nil && !errors.Is(err, context.Canceled) {
						// Error already logged by WSUplink.Start if it was a dial error
					} else {
						s.log.Info("ws uplink exited")
					}
				}

				// Backoff before reconnect unless cancelled
				boDelay := bo.NextDelay()
				s.log.Info("reconnect backoff", "sleep", boDelay)
				if !backoff.SleepCtx(ctx.Done(), boDelay) {
					return
				}
			}
		}()
	} else {
		s.log.Info("netagent feature disabled; skipping connect loop")
	}

	for {
		select {
		case <-ctx.Done():
			return nil
		case err := <-errCh:
			if err != nil {
				s.log.Error("worker error", "error", err)
			}
		case t := <-func() <-chan time.Time {
			if hb != nil {
				return hb.C
			}
			return nil
		}():
			// Heartbeat tick
			s.log.Info("heartbeat", "time", t.Format(time.RFC3339))
			if sysCollector != nil {
				// Collect a brief snapshot; use the same ctx (fast operations only)
				if info, err := sysCollector.Collect(ctx); err == nil {
					ipCount := len(info.IPs)
					s.log.Info("system snapshot",
						"os", info.OS,
						"arch", info.Arch,
						"cpu", info.CPUCount,
						"host", info.Hostname,
						"ip_count", ipCount,
					)
				} else {
					s.log.Warn("systeminfo collect failed", "error", err)
				}
			}
		}
	}
}
